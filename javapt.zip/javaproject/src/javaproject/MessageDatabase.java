package javaproject;

import java.io.*;

public class MessageDatabase {
    public static synchronized void saveMessage(String fileName, String message) {
        try (FileWriter writer = new FileWriter(fileName, true);
             BufferedWriter buffer = new BufferedWriter(writer)) {
            buffer.write(message);
            buffer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
